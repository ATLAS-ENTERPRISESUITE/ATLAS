#!/usr/bin/env bash
set -euo pipefail

REPO="https://github.com/atlasenterprisesuite/atlasenterprisesuite.git"
BRANCH="backup/2026-09-08-df606d8"
COMMIT="df606d8075fde53223c9e4493db94f24f146dc4f"

git clone "$REPO" atlasenterprisesuite
cd atlasenterprisesuite
git fetch origin "$BRANCH"
git checkout --detach "$COMMIT"

ACTUAL="$(git rev-parse HEAD)"
if [ "$ACTUAL" != "$COMMIT" ]; then
  echo "ERROR: expected $COMMIT but got $ACTUAL" >&2
  exit 1
fi

npm ci
npm test
npm run build

echo "ATLAS restored and build/test commands completed at $COMMIT"
