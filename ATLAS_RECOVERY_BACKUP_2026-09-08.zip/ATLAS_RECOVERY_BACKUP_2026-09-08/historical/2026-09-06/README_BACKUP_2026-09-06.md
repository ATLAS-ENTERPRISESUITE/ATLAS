# ATLAS Enterprise Suite — Backup Snapshot

**Captured:** 2026-09-06T10:40:00-04:00  
**Canonical repository:** `atlasenterprisesuite/atlasenterprisesuite`  
**Canonical branch:** `main`  
**Head commit:** `f9bd4c72bad92dbc2169dff7ad237d77cdd32b43`  
**Git tree:** `5368f4e9d39797b0ed43074782bd46d2873e3663`  
**Snapshot branch:** `backup/2026-09-06-1040`  

## What this backup protects

The complete Git source state is pinned by the backup branch at the exact commit above.  
This portable package adds a file-level Git manifest, recent commit history, restore instructions, and integrity hashes.

## Current repository areas represented

- CI/CD: GitHub Actions for Accounts Payable, ATLAS consensus gates, and production deploy.
- Web application: ATLAS shell, Finance/Accounting Payables, Health UI components and health endpoints.
- Core packages: Accounting, Core, and Health research/evidence packages.
- Knowledge: Humanity Atlas foundations, body systems and cardiovascular material.
- Architecture/governance: ATLAS Manager infrastructure control plane and canonical repository governance.
- Plans/specifications: Accounting, Health/AdventHealth, MiFi Control, Apple Personal Voice bridge, and Personal Voice core web.
- Verification: unit/integration tests plus Vercel configuration.

## Restore

```bash
git clone <authenticated-clone-url>
cd atlasenterprisesuite
git checkout backup/2026-09-06-1040
# Equivalent exact restore point:
git checkout f9bd4c72bad92dbc2169dff7ad237d77cdd32b43
npm ci
npm test
npm run build
```

Then restore environment/provider configuration from the authorized secret store and validate GitHub → Vercel → Cloudflare → Supabase → Production through ATLAS Manager.

## Exclusions by design

No secrets, tokens, passwords, production credentials, Supabase service-role keys, database dump, or external provider data are embedded here.

## Portable formats in this package

- JSON — machine-readable canonical manifest
- YAML — infrastructure-friendly manifest
- CSV — file inventory
- TXT — emergency human-readable restore summary
- Markdown — documentation/restore guide
- ZIP and TAR.GZ — portable packaging
