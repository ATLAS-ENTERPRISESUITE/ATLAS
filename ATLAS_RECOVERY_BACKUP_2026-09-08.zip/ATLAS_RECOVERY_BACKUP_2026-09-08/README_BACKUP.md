# ATLAS Enterprise Suite — Recovery Backup

Captured: 2026-09-08T14:14:53-04:00
Repository: `atlasenterprisesuite/atlasenterprisesuite`
Canonical branch: `main`
Snapshot branch: `backup/2026-09-08-df606d8`
Exact commit: `df606d8075fde53223c9e4493db94f24f146dc4f`
Git tree: `c4acd2d8e2a0d1fa4e2946c8ead9bf1f1a66ec31`

## What is protected

A dedicated GitHub recovery branch was created at the exact current `main` commit. Future changes to `main` do not move this backup branch unless someone explicitly updates or deletes it.

The current repository tree was verified recursively and includes the ATLAS web app, Accounting, Health, ATLAS Manager architecture/governance, Humanity Atlas knowledge, Supabase Edge Functions/migrations, tests, CI/CD workflows, and production configuration.

## Restore the source

Authenticated GitHub access is required because the repository is private.

### macOS / Linux

```bash
git clone https://github.com/atlasenterprisesuite/atlasenterprisesuite.git
cd atlasenterprisesuite
git fetch origin backup/2026-09-08-df606d8
git checkout --detach df606d8075fde53223c9e4493db94f24f146dc4f
npm ci
npm test
npm run build
```

### Windows PowerShell

Run `restore_atlas.ps1` included in this package.

## Source ZIP from GitHub

`https://github.com/atlasenterprisesuite/atlasenterprisesuite/archive/refs/heads/backup/2026-09-08-df606d8.zip`

Open that URL while signed in to the GitHub account that has access to the private repository.

## Important limitation

This portable ZIP does not embed the private repository's binary archive because the connected GitHub interface does not expose private repository archive bytes for direct local export. The complete source state itself is protected by the dedicated backup branch at the exact commit above.

No passwords, API tokens, service-role keys, database dumps, or external-provider secrets are included.

## Historical fallback

The `historical/2026-09-06/` folder contains the earlier recovery metadata from the September 6 snapshot, including its manifest and restore scripts.
