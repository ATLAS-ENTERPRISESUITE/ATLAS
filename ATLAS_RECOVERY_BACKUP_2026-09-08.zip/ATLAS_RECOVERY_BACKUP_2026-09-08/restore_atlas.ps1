$ErrorActionPreference = "Stop"
$Repo = "https://github.com/atlasenterprisesuite/atlasenterprisesuite.git"
$Branch = "backup/2026-09-08-df606d8"
$Commit = "df606d8075fde53223c9e4493db94f24f146dc4f"

git clone $Repo atlasenterprisesuite
Set-Location atlasenterprisesuite
git fetch origin $Branch
git checkout --detach $Commit

$Actual = (git rev-parse HEAD).Trim()
if ($Actual -ne $Commit) {
    throw "Expected $Commit but got $Actual"
}

npm ci
npm test
npm run build

Write-Host "ATLAS restored and build/test commands completed at $Commit"
